#encoding=utf-8

import time
import cv2


video=cv2.VideoCapture(0)
print(video)

saveFile = "face10.jpg"
faceConfig = r"D:/software_install/opencv4.1.2/opencv/sources/data/haarcascades/haarcascade_frontalface_default.xml"
#加载用于检测脸的特征文件
facescas=cv2.CascadeClassifier(faceConfig)

while 1:
   rect,imgs=video.read()
   
   # 开始检测人脸
   faces=facescas.detectMultiScale(imgs,scaleFactor=1.05,minNeighbors=40,minSize=(20,20))
   
   for x,y,w,h in faces:
       imgs=  cv2.rectangle(imgs,(x,y),(x+w,y+h),(255,0,0),2)
       
   cv2.imshow("WindowName",imgs)
   
   #等待10ms  Esc==27 
   if cv2.waitKey(10)==27:
        cv2.imwrite(saveFile,imgs)
        video.release()
        cv2.destroyAllWindows()
        break







#encoding=utf-8
import  cv2
import os

saveFile = "face5.jpg"
faceConfig = r"D:/software_install/opencv4.1.2/opencv/sources/data/haarcascades/haarcascade_frontalface_default.xml"
eyeConfig = r"D:/software_install/opencv4.1.2/opencv/sources/data/haarcascades/haarcascade_eye.xml"

#加载用于检测脸的特征文件
facescascades=cv2.CascadeClassifier(faceConfig)

imgs=cv2.imread("img/2.png")

# 开始检测人脸
faces=facescascades.detectMultiScale(imgs,scaleFactor=1.01,minNeighbors=40,minSize=(10,10))

for x,y,w,h in faces:
    cv2.rectangle(imgs,(x,y),(x+w,y+h),(0,0,255),2)

if os.path.exists(saveFile):
    os.remove(saveFile)
    
cv2.imwrite(saveFile,imgs)

print("done")


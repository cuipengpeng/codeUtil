package com.pushtest.util;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import android.os.Environment;

public class ExcelUtil{

	public static void createSheet(String fileName, String sheetName){
		FileInputStream in = null;
	    HSSFWorkbook workbook = null;

	    try{
	      in = new FileInputStream(fileName +".xls");//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("Create sheet error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
	    	System.out.println("Create sheet error(close instream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    HSSFSheet sheet = workbook.cloneSheet(1);
	    workbook.setSheetName(workbook.getSheetIndex(sheet.getSheetName()), sheetName);
	    
	    FileOutputStream out = null;
	    try{
	      out = new FileOutputStream(fileName + ".xls");
	      workbook.write(out);//����HSSFWorkbook���write����д�뵽�����
	    }catch(IOException e){
	      System.out.println("Create sheet error!" );
	      System.out.println(e.toString());
	    }finally{
	      try {
	        out.close();
	      }catch(IOException e){
	    	System.out.println("Create sheet error(close outstream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	}
	
	public static boolean sheetNotExist(String fileName, String sheetName){
		boolean sheetNotExist = true;
		
		FileInputStream in = null;
	    HSSFWorkbook workbook = null;

	    try{
	      in = new FileInputStream(fileName +".xls");//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("Check sheet excist error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
	    	System.out.println("Check sheet excist error(close instream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    int indexCount = workbook.getNumberOfSheets();
	    for(int i=0; i<indexCount; i++){
	    	if(workbook.getSheetAt(i).getSheetName().equals(sheetName)){
	    		sheetNotExist = false;
	    	}
	    }
	    
	    return sheetNotExist;
	}
	
	public static String readExcel(String fileName, String sheetName,int x, int y){
		String value = "";
		
		FileInputStream in = null;
	    HSSFWorkbook workbook = null;
	    try{
	      in = new FileInputStream(fileName +".xls");//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("readExcel error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
	    	System.out.println("readExcel error(close stream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    HSSFSheet sheet = workbook.getSheet(sheetName);	    
	    HSSFRow row = sheet.getRow(x);

	    HSSFCell cell = row.getCell(y);
	    return value = cell.getStringCellValue();
	}
	
	
	public static int[] getSDCardExcelRowAndCol(String fileName, String sheetName){
		String value = "";
		File excelFile = new File(Environment.getExternalStorageDirectory(),fileName+".xls");

		FileInputStream in = null;
	    HSSFWorkbook workbook = null;
	    try{
	      in = new FileInputStream(excelFile);//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("readExcel error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
	    	System.out.println("readExcel error(close stream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    HSSFSheet sheet = workbook.getSheet(sheetName);	    
		//获取总行数
		int rowNum=sheet.getLastRowNum();
		
		//获取总列数
		HSSFRow row=sheet.getRow(1);
		int colNum=row.getPhysicalNumberOfCells();
		int[] rowAndCol = new int [2];
		rowAndCol[0] = rowNum;
		rowAndCol[1] = colNum;
		return rowAndCol;
	}
	

	public static String readSDCardExcel(String fileName, String sheetName,int x, int y){
		String value = "";
		File excelFile = new File(Environment.getExternalStorageDirectory(),fileName+".xls");
		
		FileInputStream in = null;
	    HSSFWorkbook workbook = null;
	    try{
	      in = new FileInputStream(excelFile);//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("readExcel error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
	    	System.out.println("readExcel error(close stream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    HSSFSheet sheet = workbook.getSheet(sheetName);	    
	    HSSFRow row = sheet.getRow(x);
	    HSSFCell cell = row.getCell(y);
	    
	    String cellValue = null;
	    if(cell != null){
		    // 单元格为字符串的情况  
		    if (HSSFCell.CELL_TYPE_STRING == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getStringCellValue()); 
	            cellValue = cell.getStringCellValue();
	        }  
	        // 单元格为布尔型的情况  
	        else if (HSSFCell.CELL_TYPE_BOOLEAN == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getBooleanCellValue());  
	            cellValue = String.valueOf(cell.getBooleanCellValue());
	        }  
	        // 单元格为数字型的情况  
	        else if (HSSFCell.CELL_TYPE_NUMERIC == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getNumericCellValue()); 
	            cellValue = String.valueOf(cell.getNumericCellValue());
	
	        }  
	        // 单元格为日期型的情况  
	        else if (HSSFDateUtil.isCellDateFormatted(cell)) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getDateCellValue());  
	            cellValue = String.valueOf(cell.getDateCellValue());
	        }  
	        // 单元格为计算公式型的情况  
	        else if (HSSFCell.CELL_TYPE_FORMULA == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getCellFormula());  
	            cellValue = String.valueOf(cell.getCellFormula());
	        }  
	        // 单元格为错误型的情况  
	        else if (HSSFCell.CELL_TYPE_ERROR == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + cell.getErrorCellValue());  
	            cellValue = String.valueOf(cell.getErrorCellValue());
	        }  
	        // 单元格为空的情况  
	        else if (HSSFCell.CELL_TYPE_BLANK == cell.getCellType()) {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + "单元格为空"); 
	            cellValue = "";
	        }  
	        // 其他  
	        else {  
	            System.out.println("第" + cell.getCellNum() + "个单元格:"  
	                    + "其他情形");  
	            cellValue = "";
	        }  
	    }
	    
	    return cellValue;
	}
	
	public static void writeExcel(String fileName, String sheetName, String content, int x, int y){
		FileInputStream in = null;
	    HSSFWorkbook workbook = null;
	    try{
	      in = new FileInputStream(fileName +".xls");//��excel�ļ�תΪ������
	      POIFSFileSystem fs = new POIFSFileSystem(in);//����POIFSFileSystem�����������������
	      workbook = new HSSFWorkbook(fs);//������workbook�����POIFSFileSystem����
	    }catch(IOException e){
	      System.out.println("writeExcel error!" );
	      System.out.println(e.toString());
	    }finally{
	      try{
	        in.close();
	      }catch (IOException e){
		    System.out.println("writeExcel error(close stream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	    
	    HSSFSheet sheet = workbook.getSheet(sheetName);	    
	    HSSFRow row = sheet.getRow(x);

	    HSSFCell cell = row.createCell(y);
	    cell.setCellValue(content);
	    
	    HSSFCellStyle style1 = workbook.createCellStyle();
	    style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
	    style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	    style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
	    style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	    style1.setFillForegroundColor(HSSFColor.AUTOMATIC.index);
	    style1.setFillBackgroundColor(HSSFColor.BLUE_GREY.index);
	    cell.setCellStyle(style1);
	    
	    
	    
	    FileOutputStream out = null;
	    try{
	      out = new FileOutputStream(fileName + ".xls");
	      workbook.write(out);//����HSSFWorkbook���write����д�뵽�����
	    }catch(IOException e){
	      System.out.println("writeExcel error!" );
	      System.out.println(e.toString());
	    }finally{
	      try {
	        out.close();
	      }catch(IOException e){
	    	System.out.println("writeExcel error(close stream error)!" );
	        System.out.println(e.toString());
	      }
	    }
	}
		
}
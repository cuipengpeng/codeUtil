/** Automatically generated file. DO NOT MODIFY */
package com.downloader;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}